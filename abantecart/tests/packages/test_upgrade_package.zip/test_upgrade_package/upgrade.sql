ALTER TABLE `ac_customer_groups` ADD COLUMN `test_column` varchar(255) NOT NULL COMMENT 'translatable';
