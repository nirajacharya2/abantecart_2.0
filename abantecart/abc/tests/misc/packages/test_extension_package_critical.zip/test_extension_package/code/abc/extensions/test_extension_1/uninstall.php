<?php

namespace abc\controllers\admin;

use abc\core\lib\AResourceManager;

if ( ! class_exists( 'abc\core\ABC' ) ) {
    header( 'Location: static_pages/?forbidden='.basename( __FILE__ ) );
}

$rm = new AResourceManager();
$rm->setType( 'image' );

$resources = $rm->getResources( 'extensions', 'test_extension_1' );
if ( is_array( $resources ) ) {
    foreach ( $resources as $resource ) {
        $rm->deleteResource( $resource['resource_id'] );
    }
}
