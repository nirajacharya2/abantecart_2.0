<?php
if ( ! class_exists( 'abc\core\ABC' ) ) {
    header( 'Location: static_pages/?forbidden='.basename( __FILE__ ) );
}

require_once( 'core/test_extension_1.php' );

$controllers = array(
    'storefront' => array( 'responses/extension/test_extension_1' ),
    'admin'      => array( 'responses/extension/test_extension_1' ),
);

$models = array(
    'storefront' => array( 'extension/test_extension_1' ),
    'admin'      => array( 'extension/test_extension_1' ),
);

$languages = array(
    'storefront' => array(
        'test_extension_1/test_extension_1',
    ),
    'admin'      => array(
        'test_extension_1/test_extension_1',
    ),
);

$templates = array(
    'storefront' => array(
        'responses/test_extension_1.tpl',
    ),
    'admin'      => array(
        'pages/extension/test_extension_1_settings.tpl',
        'pages/sale/test_extension_1_details.tpl',
    ),
);
