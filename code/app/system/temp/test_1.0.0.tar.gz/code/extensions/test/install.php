<?php


if (! defined ( 'DIR_CORE' )) {
 header ( 'Location: static_pages/' );
}





//before install validate it is unique
$lng_code = "tl";
$lng_name = "test Language";
$lng_directory = "test";
$lng_locale = "tl_TL.UTF-8,tl_TL,tl-tl,test";
$lng_flag_path = "";
$lng_sort = 2; // sorting order with other languages
$lng_status = 0; // Status on installation of extension

$query = $this->db->query("SELECT language_id
							FROM ".$this->db->table("languages")."
							WHERE code='".$this->db->escape($lng_code)."'");
if ($query->row["language_id"]) {
	$this->session->data["error"] = "Error: Language with ".$lng_code." code is already installed! Can not install duplicate languages! Uninstall this extension before attempting again.";
	$error = new AError ($this->session->data["error"]);
	$error->toLog()->toDebug();
	return false;
}

$this->db->query("INSERT INTO ".$this->db->table("languages")." 
				(`name`,`code`,`locale`,`image`,`directory`,`filename`,`sort_order`, `status`)
				VALUES (
				'".$this->db->escape($lng_name)."', 
				'".$this->db->escape($lng_code)."', 
				'".$this->db->escape($lng_locale)."', 
				'".$this->db->escape($lng_flag_path)."',
				'".$this->db->escape($lng_directory)."',
				'".$lng_directory."',
				".(int)$lng_sort.",
				".(int)$lng_status.");");
$new_language_id = $this->db->getLastId();
